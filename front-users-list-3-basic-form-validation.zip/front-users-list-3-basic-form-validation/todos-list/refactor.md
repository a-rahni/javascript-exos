# Refactors

- Mettre les appels réseau dans des services
- Créer des composant pour le code UI réutilisables
- Créer des constantes globales(url de base)
- Réorganiser la structure du projet
