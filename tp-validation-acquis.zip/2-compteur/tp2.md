#Compteur

Le but de ce TP est de créer un compteur qui possède 3 boutons:

- Increase : Pour incrémenter la valeur
- Decrease : Pour décrementer la valeur
- Reset : Pour réinitialiser la valeur à zéro

Il faut noter que la valeur de départ est zéro.

Quand la valeur est 0, la couleur du compteur es noire, quand la valeur est supérieure à 0, la couleur est verte, et quand la valeur est inférieure à 0, la couleur est rouge.

Exemple d'exécution
![Alt Text](https://res.cloudinary.com/jochri3/image/upload/v1658913419/gif%20exercices/tp2-counter.gif)
