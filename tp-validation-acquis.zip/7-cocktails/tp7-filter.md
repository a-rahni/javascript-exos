#Filtre menu

Le but de ce TP est d'afficher les cocktails avec la possibilité de filtrer le résulat:

Pour les données, vous devez faire un appel HTTP vers [cet endpoint](https://www.thecocktaildb.com/api/json/v1/1/search.php?s=a).

Les attributs à considérer sont : `strDrink` et `strDrinkThumb` pour l'affichage.

Voici l'exemple d'exécution

![Alt Text](https://res.cloudinary.com/jochri3/image/upload/v1658922166/gif%20exercices/tp7-filter.gif)
